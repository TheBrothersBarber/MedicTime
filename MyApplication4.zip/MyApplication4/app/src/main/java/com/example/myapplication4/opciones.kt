package com.example.myapplication4

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class OpcionesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.opciones)

        // Referencias a los TextViews de saludo
        val greetingTextView: TextView = findViewById(R.id.textViewGreeting)
        val goodMorningTextView: TextView = findViewById(R.id.textViewGoodMorning)

        // Referencias a los botones
        val buttonCart: Button = findViewById(R.id.buttonCart)
        val buttonMaps: Button = findViewById(R.id.buttonMaps)
        val buttonInbox: Button = findViewById(R.id.buttonInbox)
        val buttonSettings: Button = findViewById(R.id.buttonSettings)
        val buttonFavorite: Button = findViewById(R.id.buttonFavorite)
        val buttonLogout: Button = findViewById(R.id.buttonLogout)

        // Configuración de listeners para los botones
        buttonCart.setOnClickListener {
            Toast.makeText(this, "Cart clicked", Toast.LENGTH_SHORT).show()
            // Aquí puedes agregar la acción para el botón "Cart"
        }

        buttonMaps.setOnClickListener {
            Toast.makeText(this, "Maps clicked", Toast.LENGTH_SHORT).show()
            // Aquí puedes agregar la acción para el botón "Maps"
        }

        buttonInbox.setOnClickListener {
            Toast.makeText(this, "Inbox clicked", Toast.LENGTH_SHORT).show()
            // Aquí puedes agregar la acción para el botón "Inbox"
        }

        buttonSettings.setOnClickListener {
            Toast.makeText(this, "Settings clicked", Toast.LENGTH_SHORT).show()
            // Aquí puedes agregar la acción para el botón "Settings"
        }

        buttonFavorite.setOnClickListener {
            Toast.makeText(this, "Favorite clicked", Toast.LENGTH_SHORT).show()
            // Aquí puedes agregar la acción para el botón "Favorite"
        }

        buttonLogout.setOnClickListener {
            Toast.makeText(this, "Logout clicked", Toast.LENGTH_SHORT).show()
            // Aquí puedes agregar la acción para el botón "Logout"
        }
    }
}
